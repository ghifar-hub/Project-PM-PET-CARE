import 'package:flutter/material.dart';

class DeviceSwitch extends StatefulWidget {
  final String title;

  const DeviceSwitch({
    super.key,
    required this.title,
  });

  @override
  State<DeviceSwitch> createState() => _DeviceSwitchState();
}

class _DeviceSwitchState extends State<DeviceSwitch> {
  bool isOn = false;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: SwitchListTile(
        value: isOn,

        onChanged: (value) {
          setState(() {
            isOn = value;
          });
        },

        title: Text(widget.title),
        activeColor: Colors.green,
      ),
    );
  }
}