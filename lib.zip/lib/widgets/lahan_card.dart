import 'package:flutter/material.dart';

class LahanCard extends StatelessWidget {
  final String title;
  final String subtitle;

  const LahanCard({
    super.key,
    required this.title,
    required this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: const Icon(
          Icons.landscape,
          color: Colors.green,
        ),

        title: Text(title),
        subtitle: Text(subtitle),
      ),
    );
  }
}