// import 'package:flutter/material.dart';
// import 'home_page.dart';

// class LoginPage extends StatelessWidget {
//   const LoginPage({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Padding(
//         padding: const EdgeInsets.all(25),

//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             const Icon(
//               Icons.eco,
//               color: Colors.green,
//               size: 100,
//             ),

//             const SizedBox(height: 20),

//             const Text(
//               "AgriSmart",
//               style: TextStyle(
//                 fontSize: 32,
//                 fontWeight: FontWeight.bold,
//                 color: Colors.green,
//               ),
//             ),

//             const SizedBox(height: 40),

//             TextField(
//               decoration: InputDecoration(
//                 hintText: "Email",
//                 border: OutlineInputBorder(
//                   borderRadius: BorderRadius.circular(15),
//                 ),
//               ),
//             ),

//             const SizedBox(height: 20),

//             TextField(
//               obscureText: true,
//               decoration: InputDecoration(
//                 hintText: "Password",
//                 border: OutlineInputBorder(
//                   borderRadius: BorderRadius.circular(15),
//                 ),
//               ),
//             ),

//             const SizedBox(height: 30),

//             SizedBox(
//               width: double.infinity,
//               height: 55,

//               child: ElevatedButton(
//                 style: ElevatedButton.styleFrom(
//                   backgroundColor: Colors.green,
//                 ),

//                 onPressed: () {
//                   Navigator.pushReplacement(
//                     context,
//                     MaterialPageRoute(
//                       builder: (_) => const HomePage(),
//                     ),
//                   );
//                 },

//                 child: const Text(
//                   "Masuk",
//                   style: TextStyle(fontSize: 18),
//                 ),
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }

import 'package:flutter/material.dart';
import 'home_page.dart';
import 'forgot_password_page.dart';
import 'register_page.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  bool isHidden = true;
  bool isChecked = false;

  final TextEditingController emailController =
      TextEditingController();

  final TextEditingController passwordController =
      TextEditingController();

  @override
  void dispose() {
    emailController.dispose();
    passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffDDE8D3),

      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: 25,
              vertical: 20,
            ),

            child: Column(
              children: [
                const SizedBox(height: 40),

                //////////////////////////////////////
                /// LOGO
                //////////////////////////////////////

                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(
                    vertical: 35,
                  ),

                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(50),
                  ),

                  child: Column(
                    children: [
                      const Icon(
                        Icons.eco,
                        color: Colors.green,
                        size: 70,
                      ),

                      const SizedBox(height: 10),

                      RichText(
                        text: const TextSpan(
                          children: [
                            TextSpan(
                              text: "Agri",
                              style: TextStyle(
                                color: Color(0xff1D6B2D),
                                fontSize: 38,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            TextSpan(
                              text: "Smart",
                              style: TextStyle(
                                color: Color(0xff6CBF58),
                                fontSize: 38,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 50),

                //////////////////////////////////////
                /// DESKRIPSI
                //////////////////////////////////////

                const Text(
                  "Sistem Monitoring dan Pengelolaan\n"
                  "Pertanian Berbasis IoT\n"
                  "Untuk Petani Desa",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Color(0xff35566A),
                    fontWeight: FontWeight.bold,
                    fontSize: 15,
                    height: 1.6,
                  ),
                ),

                const SizedBox(height: 50),

                //////////////////////////////////////
                /// EMAIL
                //////////////////////////////////////

                TextField(
                  controller: emailController,

                  decoration: const InputDecoration(
                    prefixIcon: Icon(
                      Icons.mail_outline,
                      color: Color(0xff35566A),
                    ),

                    hintText: "Alamat email",

                    enabledBorder: UnderlineInputBorder(
                      borderSide: BorderSide(
                        color: Colors.black38,
                      ),
                    ),

                    focusedBorder: UnderlineInputBorder(
                      borderSide: BorderSide(
                        color: Colors.green,
                        width: 2,
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 25),

                //////////////////////////////////////
                /// PASSWORD
                //////////////////////////////////////

                TextField(
                  controller: passwordController,
                  obscureText: isHidden,

                  decoration: InputDecoration(
                    prefixIcon: const Icon(
                      Icons.lock_outline,
                      color: Color(0xff35566A),
                    ),

                    hintText: "Password",

                    suffixIcon: IconButton(
                      onPressed: () {
                        setState(() {
                          isHidden = !isHidden;
                        });
                      },

                      icon: Icon(
                        isHidden
                            ? Icons.visibility_outlined
                            : Icons.visibility_off_outlined,
                      ),
                    ),

                    enabledBorder: const UnderlineInputBorder(
                      borderSide: BorderSide(
                        color: Colors.black38,
                      ),
                    ),

                    focusedBorder: const UnderlineInputBorder(
                      borderSide: BorderSide(
                        color: Colors.green,
                        width: 2,
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 20),

                //////////////////////////////////////
                /// REMEMBER ME + FORGOT PASSWORD
                //////////////////////////////////////

                Row(
                  children: [
                    Checkbox(
                      value: isChecked,

                      activeColor: Colors.green,

                      onChanged: (value) {
                        setState(() {
                          isChecked = value!;
                        });
                      },
                    ),

                    const Text(
                      "Ingat Saya",
                      style: TextStyle(
                        fontWeight: FontWeight.w500,
                      ),
                    ),

                    const Spacer(),

                    GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) =>
                                const ForgotPasswordPage(),
                          ),
                        );
                      },

                      child: const Text(
                        "Lupa Password ?",
                        style: TextStyle(
                          color: Colors.green,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 25),

                //////////////////////////////////////
                /// BUTTON LOGIN
                //////////////////////////////////////

                SizedBox(
                  width: double.infinity,
                  height: 55,

                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xff3A9638),
                      shape: RoundedRectangleBorder(
                        borderRadius:
                            BorderRadius.circular(30),
                      ),
                    ),

                    onPressed: () {
                      Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(
                          builder: (_) => const HomePage(),
                        ),
                      );
                    },

                    child: const Text(
                      "Masuk",
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 25),

                //////////////////////////////////////
                /// REGISTER
                //////////////////////////////////////

                Row(
                  mainAxisAlignment:
                      MainAxisAlignment.center,

                  children: [
                    const Text(
                      "Belum Punya Akun? ",
                    ),

                    GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) =>
                                const RegisterPage(),
                          ),
                        );
                      },

                      child: const Text(
                        "Daftar Disini",
                        style: TextStyle(
                          color: Colors.green,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}