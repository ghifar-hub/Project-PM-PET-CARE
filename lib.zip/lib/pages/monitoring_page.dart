import 'package:flutter/material.dart';
import '../widgets/sensor_card.dart';

class MonitoringPage extends StatelessWidget {
  const MonitoringPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Monitoring Sensor"),
        backgroundColor: Colors.green,
      ),

      body: ListView(
        padding: const EdgeInsets.all(16),

        children: const [
          SensorCard(
            title: "Suhu Udara",
            value: "28°C",
          ),

          SensorCard(
            title: "Kelembapan Tanah",
            value: "65%",
          ),

          SensorCard(
            title: "pH Tanah",
            value: "6.5",
          ),

          SensorCard(
            title: "Cahaya",
            value: "800 lux",
          ),
        ],
      ),
    );
  }
}