import 'package:flutter/material.dart';
import '../widgets/device_switch.dart';

class PerangkatPage extends StatelessWidget {
  const PerangkatPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Kontrol Perangkat"),
        backgroundColor: Colors.green,
      ),

      body: ListView(
        padding: const EdgeInsets.all(16),

        children: const [
          DeviceSwitch(title: "Pompa Air"),
          DeviceSwitch(title: "Irigasi"),
          DeviceSwitch(title: "Lampu Grow"),
        ],
      ),
    );
  }
}