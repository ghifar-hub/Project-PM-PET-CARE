import 'package:flutter/material.dart';
import 'status_sensor_page.dart';

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffDDE8D3),

      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(18),

          child: Column(
            crossAxisAlignment:
                CrossAxisAlignment.start,

            children: [
              //////////////////////////////////////
              /// TOP BAR
              //////////////////////////////////////

              Row(
                mainAxisAlignment:
                    MainAxisAlignment.spaceBetween,

                children: const [
                  Icon(
                    Icons.menu,
                    size: 28,
                  ),

                  Icon(
                    Icons.notifications_none,
                    size: 28,
                  ),
                ],
              ),

              const SizedBox(height: 20),

              //////////////////////////////////////
              /// HEADER
              //////////////////////////////////////

              const Text(
                "Hallo Pak Budi, 👋",
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 5),

              const Text(
                "Selamat Datang Di AgriSmart",
                style: TextStyle(
                  color: Colors.black54,
                  fontSize: 15,
                ),
              ),

              const SizedBox(height: 25),

              //////////////////////////////////////
              /// WEATHER CARD
              //////////////////////////////////////

              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),

                decoration: BoxDecoration(
                  color: const Color(0xff3D9B3D),
                  borderRadius:
                      BorderRadius.circular(22),
                ),

                child: Row(
                  mainAxisAlignment:
                      MainAxisAlignment.spaceBetween,

                  children: [
                    Row(
                      children: [
                        const Icon(
                          Icons.cloud,
                          color: Colors.yellow,
                          size: 55,
                        ),

                        const SizedBox(width: 15),

                        Column(
                          crossAxisAlignment:
                              CrossAxisAlignment.start,

                          children: const [
                            Text(
                              "Cuaca hari ini",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 15,
                              ),
                            ),

                            SizedBox(height: 10),

                            Text(
                              "20°C",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 38,
                                fontWeight:
                                    FontWeight.bold,
                              ),
                            ),

                            Text(
                              "Berawan",
                              style: TextStyle(
                                color: Colors.white,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),

                    Column(
                      crossAxisAlignment:
                          CrossAxisAlignment.start,

                      children: const [
                        Text(
                          "Kelembapan",
                          style: TextStyle(
                            color: Colors.white70,
                          ),
                        ),

                        SizedBox(height: 5),

                        Text(
                          "70%",
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight:
                                FontWeight.bold,
                            fontSize: 22,
                          ),
                        ),

                        SizedBox(height: 15),

                        Text(
                          "Angin",
                          style: TextStyle(
                            color: Colors.white70,
                          ),
                        ),

                        SizedBox(height: 5),

                        Text(
                          "40km/jam",
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight:
                                FontWeight.bold,
                            fontSize: 18,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 25),

              //////////////////////////////////////
              /// RINGKASAN
              //////////////////////////////////////

              const Text(
                "Ringkasan Lahan",
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 15),

              Row(
                children: [
                  Expanded(
                    child: Container(
                      padding:
                          const EdgeInsets.all(15),

                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius:
                            BorderRadius.circular(
                          15,
                        ),
                      ),

                      child: const Column(
                        crossAxisAlignment:
                            CrossAxisAlignment.start,

                        children: [
                          Text(
                            "Total lahan",
                            style: TextStyle(
                              fontSize: 13,
                              color: Colors.black54,
                            ),
                          ),

                          SizedBox(height: 10),

                          Text(
                            "3",
                            style: TextStyle(
                              fontSize: 25,
                              fontWeight:
                                  FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                  const SizedBox(width: 15),

                  Expanded(
                    child: Container(
                      padding:
                          const EdgeInsets.all(15),

                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius:
                            BorderRadius.circular(
                          15,
                        ),
                      ),

                      child: const Column(
                        crossAxisAlignment:
                            CrossAxisAlignment.start,

                        children: [
                          Text(
                            "Luas total",
                            style: TextStyle(
                              fontSize: 13,
                              color: Colors.black54,
                            ),
                          ),

                          SizedBox(height: 10),

                          Text(
                            "2.5 ha",
                            style: TextStyle(
                              fontSize: 25,
                              fontWeight:
                                  FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 25),

              //////////////////////////////////////
              /// STATUS SENSOR
              //////////////////////////////////////

              Row(
                mainAxisAlignment:
                    MainAxisAlignment.spaceBetween,

                children: const [
                  Text(
                    "Status Sensor",
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),

                  Text(
                    "Lihat Semua >",
                    style: TextStyle(
                      color: Colors.green,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 15),

              Container(
                padding: const EdgeInsets.all(15),

                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius:
                      BorderRadius.circular(18),
                ),

                child: Column(
                  children: [
                    sensorTile(
                      Icons.thermostat,
                      Colors.blue,
                      "Suhu",
                      "28°C",
                    ),

                    Divider(),

                    sensorTile(
                      Icons.water_drop,
                      Colors.lightBlue,
                      "Kelembapan tanah",
                      "70%",
                    ),

                    Divider(),

                    sensorTile(
                      Icons.eco,
                      Colors.green,
                      "pH tanah",
                      "6.5",
                    ),

                    Divider(),

                    sensorTile(
                      Icons.wb_sunny,
                      Colors.orange,
                      "Cahaya",
                      "800 lux",
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  static Widget sensorTile(
    IconData icon,
    Color color,
    String title,
    String value,
  ) {
    return Row(
      children: [
        Icon(
          icon,
          color: color,
        ),

        const SizedBox(width: 12),

        Expanded(
          child: Text(
            title,
            style: const TextStyle(
              fontSize: 15,
            ),
          ),
        ),

        Text(
          value,
          style: const TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }
}