import 'package:flutter/material.dart';

class StatusSensorPage extends StatelessWidget {
  const StatusSensorPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffF4F7F1),

      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(18),

          child: Column(
            crossAxisAlignment:
                CrossAxisAlignment.start,

            children: [
              //////////////////////////////////////
              /// APP BAR
              //////////////////////////////////////

              Row(
                mainAxisAlignment:
                    MainAxisAlignment.spaceBetween,

                children: [
                  IconButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },

                    icon: const Icon(
                      Icons.arrow_back_ios,
                    ),
                  ),

                  const Text(
                    "Status Sensor",
                    style: TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                    ),
                  ),

                  const Icon(
                    Icons.tune,
                    size: 28,
                  ),
                ],
              ),

              const SizedBox(height: 25),

              //////////////////////////////////////
              /// FILTER
              //////////////////////////////////////

              SingleChildScrollView(
                scrollDirection: Axis.horizontal,

                child: Row(
                  children: [
                    filterChip(
                      "Semua",
                      true,
                    ),

                    filterChip(
                      "Suhu",
                      false,
                    ),

                    filterChip(
                      "Kelembapan",
                      false,
                    ),

                    filterChip(
                      "Tanah",
                      false,
                    ),

                    filterChip(
                      "Cahaya",
                      false,
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 25),

              //////////////////////////////////////
              /// UPDATE CARD
              //////////////////////////////////////

              Container(
                padding: const EdgeInsets.all(18),

                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius:
                      BorderRadius.circular(22),
                ),

                child: Row(
                  children: [
                    Container(
                      padding:
                          const EdgeInsets.all(12),

                      decoration: BoxDecoration(
                        color: Colors.green.shade100,
                        shape: BoxShape.circle,
                      ),

                      child: const Icon(
                        Icons.wifi,
                        color: Colors.green,
                      ),
                    ),

                    const SizedBox(width: 15),

                    const Expanded(
                      child: Column(
                        crossAxisAlignment:
                            CrossAxisAlignment.start,

                        children: [
                          Text(
                            "Terakhir diperbarui",
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight:
                                  FontWeight.w500,
                            ),
                          ),

                          SizedBox(height: 5),

                          Text(
                            "Hari ini, 19:00",
                            style: TextStyle(
                              color: Colors.black54,
                            ),
                          ),
                        ],
                      ),
                    ),

                    Container(
                      padding:
                          const EdgeInsets.symmetric(
                        horizontal: 18,
                        vertical: 12,
                      ),

                      decoration: BoxDecoration(
                        color: Colors.green.shade50,
                        borderRadius:
                            BorderRadius.circular(
                          15,
                        ),
                      ),

                      child: const Row(
                        children: [
                          Icon(
                            Icons.refresh,
                            color: Colors.green,
                          ),

                          SizedBox(width: 8),

                          Text(
                            "Perbarui",
                            style: TextStyle(
                              color: Colors.green,
                              fontWeight:
                                  FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 30),

              //////////////////////////////////////
              /// TITLE
              //////////////////////////////////////

              const Text(
                "Daftar Sensor",
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 20),

              //////////////////////////////////////
              /// SENSOR LIST
              //////////////////////////////////////

              sensorCard(
                Icons.thermostat,
                Colors.blue,
                "Suhu Udara",
                "28°C",
              ),

              sensorCard(
                Icons.water_drop,
                Colors.lightBlue,
                "Kelembapan Udara",
                "70%",
              ),

              sensorCard(
                Icons.water,
                Colors.cyan,
                "Kelembapan Tanah",
                "70%",
              ),

              sensorCard(
                Icons.eco,
                Colors.green,
                "pH Tanah",
                "6.5",
              ),

              sensorCard(
                Icons.wb_sunny,
                Colors.orange,
                "Cahaya",
                "800 lux",
              ),

              sensorCard(
                Icons.science,
                Colors.purple,
                "Nutrisi Tanah (NPK)",
                "N:60%",
              ),

              const SizedBox(height: 20),

              //////////////////////////////////////
              /// INFO
              //////////////////////////////////////

              Container(
                padding: const EdgeInsets.all(18),

                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius:
                      BorderRadius.circular(20),
                ),

                child: const Row(
                  children: [
                    CircleAvatar(
                      backgroundColor: Colors.green,
                      child: Icon(
                        Icons.info,
                        color: Colors.white,
                      ),
                    ),

                    SizedBox(width: 15),

                    Expanded(
                      child: Text(
                        "Data sensor diperbarui "
                        "secara otomatis setiap "
                        "10 menit.",
                        style: TextStyle(
                          fontSize: 15,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  //////////////////////////////////////
  /// FILTER BUTTON
  //////////////////////////////////////

  static Widget filterChip(
    String title,
    bool active,
  ) {
    return Container(
      margin: const EdgeInsets.only(right: 12),

      padding: const EdgeInsets.symmetric(
        horizontal: 25,
        vertical: 12,
      ),

      decoration: BoxDecoration(
        color:
            active ? Colors.green : Colors.white,

        borderRadius: BorderRadius.circular(30),

        border: Border.all(
          color: Colors.black12,
        ),
      ),

      child: Text(
        title,
        style: TextStyle(
          color:
              active ? Colors.white : Colors.black,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }

  //////////////////////////////////////
  /// SENSOR CARD
  //////////////////////////////////////

  static Widget sensorCard(
    IconData icon,
    Color color,
    String title,
    String value,
  ) {
    return Container(
      margin: const EdgeInsets.only(bottom: 18),
      padding: const EdgeInsets.all(18),

      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(25),
      ),

      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(18),

            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius:
                  BorderRadius.circular(18),
            ),

            child: Icon(
              icon,
              color: color,
              size: 35,
            ),
          ),

          const SizedBox(width: 18),

          Expanded(
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,

              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                  ),
                ),

                const SizedBox(height: 8),

                const Text(
                  "Lahan Sawah 1",
                  style: TextStyle(
                    color: Colors.black54,
                  ),
                ),

                const SizedBox(height: 5),

                const Text(
                  "Terakhir: Hari ini, 19:00",
                  style: TextStyle(
                    color: Colors.black54,
                  ),
                ),
              ],
            ),
          ),

          Column(
            crossAxisAlignment:
                CrossAxisAlignment.end,

            children: [
              Text(
                value,
                style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 12),

              Container(
                padding:
                    const EdgeInsets.symmetric(
                  horizontal: 15,
                  vertical: 8,
                ),

                decoration: BoxDecoration(
                  color: Colors.green.shade50,
                  borderRadius:
                      BorderRadius.circular(15),
                ),

                child: const Text(
                  "Normal",
                  style: TextStyle(
                    color: Colors.green,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}