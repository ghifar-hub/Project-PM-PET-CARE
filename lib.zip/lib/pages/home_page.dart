import 'package:flutter/material.dart';
import 'dashboard_page.dart';
import 'monitoring_page.dart';
import 'lahan_page.dart';
import 'perangkat_page.dart';
import 'profile_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int currentIndex = 0;

  final List<Widget> pages = [
    const DashboardPage(),
    const MonitoringPage(),
    const LahanPage(),
    const PerangkatPage(),
    const ProfilePage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: pages[currentIndex],

      bottomNavigationBar: BottomNavigationBar(
        currentIndex: currentIndex,
        selectedItemColor: Colors.green,
        type: BottomNavigationBarType.fixed,

        onTap: (index) {
          setState(() {
            currentIndex = index;
          });
        },

        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: "Home",
          ),

          BottomNavigationBarItem(
            icon: Icon(Icons.analytics),
            label: "Monitoring",
          ),

          BottomNavigationBarItem(
            icon: Icon(Icons.landscape),
            label: "Lahan",
          ),

          BottomNavigationBarItem(
            icon: Icon(Icons.settings_remote),
            label: "Perangkat",
          ),

          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: "Profil",
          ),
        ],
      ),
    );
  }
}