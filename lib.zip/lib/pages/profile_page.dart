import 'package:flutter/material.dart';

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.green,

      body: Column(
        children: [
          const SizedBox(height: 100),

          const CircleAvatar(
            radius: 50,
            child: Icon(Icons.person, size: 50),
          ),

          const SizedBox(height: 20),

          const Text(
            "Pak Budi",
            style: TextStyle(
              color: Colors.white,
              fontSize: 28,
              fontWeight: FontWeight.bold,
            ),
          ),

          const SizedBox(height: 30),

          Expanded(
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),

              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.vertical(
                  top: Radius.circular(30),
                ),
              ),

              child: ListView(
                children: const [
                  ListTile(
                    leading: Icon(Icons.person),
                    title: Text("Profil Saya"),
                  ),

                  ListTile(
                    leading: Icon(Icons.settings),
                    title: Text("Pengaturan"),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}