import 'package:flutter/material.dart';
import '../widgets/lahan_card.dart';

class LahanPage extends StatelessWidget {
  const LahanPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Kelola Lahan"),
        backgroundColor: Colors.green,
      ),

      body: ListView(
        padding: const EdgeInsets.all(16),

        children: const [
          LahanCard(
            title: "Lahan Sawah 1",
            subtitle: "1.0 ha",
          ),

          LahanCard(
            title: "Lahan Kebun 1",
            subtitle: "0.8 ha",
          ),
        ],
      ),
    );
  }
}